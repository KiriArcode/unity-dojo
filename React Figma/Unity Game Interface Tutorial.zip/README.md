
  # Unity Game Interface Tutorial

  This is a code bundle for Unity Game Interface Tutorial. The original project is available at https://www.figma.com/design/CFs0YsS8zGbJo27DtWjdqn/Unity-Game-Interface-Tutorial.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  